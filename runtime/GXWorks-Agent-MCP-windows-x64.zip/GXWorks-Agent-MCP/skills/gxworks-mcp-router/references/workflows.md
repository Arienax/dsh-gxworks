# 调用流程与示例

默认交付优先返回 GXW。找到 GX Works2 后，共享保存流程自动编译、保存并冷重开；读取 delivery 与 validation 的实际结果，不根据文件存在宣称编译通过。GXW 无法生成时，Ladder 降级 CSV、ST 降级为代码 TXT 与全局标签 CSV、FBD/SFC 保留结构化候选及预览，并说明原因。原生编译失败仍保留 GXW 诊断候选，不改交 CSV。新建 ST/SFC 使用 get_generation_context 返回的 operation=generate 合同。GX Works2 1.635.0.1 配合 v4 工作区适配器，按实际 CPU 查询原生系列与子系列，无基底创建对应语言工程。遵守该 CPU 的工程类型和语言条件，读取实际创建及验证结果；不使用 IDE 新建对话框、隐藏窗口控件或预制完整工程。

以下示例中的 `${...}` 均取自上一步工具的实际返回值；工具名称与参数字段以客户端当前连接的 `tools/list` schema 为准。

## 1. 只读分析外部 `.gxw` 文件

调用 `inspect_gxw_project`，传入服务端可读的 `path` 或文件内容的 `data_base64`，获取文件的 CPU 型号、程序清单与 `source_ref`（多程序工程可按清单指定 `program`）。

随后携带 `source_ref` 读取程序结构或静态诊断：

```json
{"tool":"get_current_program_info","arguments":{"source_ref":"${source_ref}"}}
```

- **Ladder**：根据返回的 `network_id` 调用 `read_network`，或调用 `get_diagnostics` / `validate_project(native=false)`。
- **ST / FBD / SFC**：调用对应的 `read_st_project`、`read_fbd_project` 或 `read_sfc_project`（在 schema 支持时传入 `source_ref`）。

## 2. 查看本机已打开的 GX Works2 程序

1. 调用 `list_gxworks2_sessions()` 获取当前打开的 GX Works2 窗口列表。
2. 按工程路径、CPU 或窗口标题匹配目标窗口，调用 `read_gxworks2_snapshot(session_id=..., program=...)` 取得 `source_ref`（存在多个窗口且无法从上下文区分时先向用户确认）。
3. 后续分析同流程 1，直接将 `source_ref` 传给读取与静态诊断工具。

## 3. 分析导出的程序 CSV 与注释 CSV

当用户提供 GX Works2 导出的程序 CSV 与软元件注释 CSV 时，连同明确的 `plc_model` 调用 `inspect_gxworks2_csv_files`（支持服务端路径或 `*_data_base64`）：

```json
{
  "tool":"inspect_gxworks2_csv_files",
  "arguments":{
    "program_path":"${server_program_csv}",
    "comment_path":"${server_comment_csv}",
    "plc_model":"${actual_cpu}"
  }
}
```

取得 `source_ref` 后即可按网络读取指令、查看绘图预览结果并运行静态分析。

## 4. 根据需求新建 Ladder 程序

1. **选择或创建工程**：若当前已选中匹配的工程则直接复用；在 `local` 模式下新建工程可调用 `create_project(name, plc_model, target_mode="ladder")`，切换已有工程用 `list_projects` → `select_project`。
2. **获取生成上下文**：

```json
{
  "tool":"get_generation_context",
  "arguments":{
    "user_requirement":"${完整原始工程需求}",
    "workflow":"direct_generation"
  }
}
```

3. **补充检索与提交候选**：优先使用上下文返回的 `generation_instructions`、规格与指令事实；仍需核对特定指令细节时调用 `search_plc_manual`。按合同生成 Ladder JSON（软元件注释遵守当前长度与格式要求），再调用 `create_program_candidate(ladder=..., generation_context_id=...)`。
4. **查看产物**：版本保存后调用 `get_project_artifacts()`，优先取得 `delivery.primary_artifact` 指向的 GXW；同时读取原生编译、保存与冷重开结果。GXW 无法生成时才按原因取得降级 CSV。

## 5. 离线修改 `.gxw` 中的单个或多个 POU

1. **导入版本**：在 `local` 模式下，若文件尚未导入为工程版本，先调用 `import_gxw_project` 创建保存版本。
2. **读取编辑模型**：调用 `read_gxw_source(program=实际逻辑名称)` 获取目标 POU 的结构、指令记录（含 `record_index`）及同工程源码清单。
3. **提交修改**：
   - 单个 Ladder 网络或原始指令补丁：调用 `patch_program`（GXW 指令级修改需传入当前 `record_index` 与完整 `expected`）。
   - 多源码、接口声明或软元件注释联合修改：调用 `edit_gxw_project`，显式传入当前 `version_id` 与 `edits`（`save_policy` 默认为 `"draft"`，需要严格拦截新增已识别错误时设为 `"checked"`）。

## 6. FBD / ST / SFC 工程读写

### FBD 与项目定义

复杂设备的 FBD 主图按功能组装 ST FB。先明确运行、工序、定时计数、报警和输出互锁的职责、状态与接口；已有定义优先复用，缺少时通过 `create_fbd_candidate(operation="create_st_fb", source_name=..., declarations=..., st_text=...)` 建立真实实现。尚无保存版本时，首个定义先按所选 CPU 无基底创建本任务的 FBD 工程；随后定义复用该保存版本，读取新上下文后用 `operation="edit"` 组装主图。重复类型使用不同实例持有独立状态。主图保留少量功能网络、具名信号和短连线；不将完整状态机摊成门电路，不以空 FB 或单个整机黑盒代替模块设计。

1. 选择实际 CPU 的 FBD 工程；外部 GXW 先导入为保存版本。生成或修改前调用 `get_generation_context`，带完整的 `user_requirement`。默认 `catalog_scope="task"` 按需求和源码依赖选择接口。
2. 使用返回的 `generation_input`，重点读取下表。单独的 `get_fbd_catalog` 默认返回全目录，不能代替这些规则；缺少指定块时，用 `templates` 精确补取，并保留 `missing_templates`。需要将新增接口及依赖纳入生成时，用同一需求和明确 `templates` 重新获取上下文。
3. 按 `output_contract` 提交。无保存版本时用 `create_fbd_candidate(operation="generate", model=...)`。已有版本默认提供 `edit_gxw_project`；只改一个图时也可采用 `output_contract.alternatives` 中的单图合同，操作值原样取自合同。

| `generation_input` 字段 | 使用方式 |
| --- | --- |
| `language_rules`、`device_address_rules` | 按 FBD 常量、类型和当前 CPU 地址规则生成；保留默认分配、可配置范围、型号条件和来源冲突。编号合法不代表本工程已分配，也不扩大原生访问权限。 |
| `catalog`、`parameter_schema`、`call_interface`、`structures` | 使用完整端口与复合类型；`IN_OUT` 按实际接口使用 `in.NAME` / `out.NAME`。不要凭块名猜端口或替换未知类型。 |
| `source_context`、`call_bindings` | 读取受影响 ST 正文、接口及全部调用者；同一 FB 实例的多次调用共享状态。修改接口时更新全部受影响调用者。 |
| `project_options`、`task_scopes`、`supported_paths` | 使用本工程条件和实际支持路径。新建 POU、库正文转移和 Ladder 转换分别判断，模板可用不代表这些操作都可用。 |
| `context_gaps`、`unknown_boundaries` | 如实保留当前未解析项；必需语言或地址规则缺失会阻止上下文生成，不能用手写假设补齐。 |

联合提交沿用工具现有 schema，例如：

```json
{
  "tool":"edit_gxw_project",
  "arguments":{
    "version_id":"${current_version_id}",
    "save_policy":"checked",
    "edits":[
      {"source_name":"${实际ST源码身份}","command":{"st_text":"${完整目标ST正文}"}},
      {"source_name":"${实际FBD调用者身份}","command":{"model":{"program":"${实际FBD调用者身份}","networks":[
        {"calls":[{"id":"${原调用ID}","type":"${实际FB类型}","instance":"${实际实例名}","arguments":{"${实际输入端口}":"${输入表达式}","${实际输出端口}":"${可写输出}"}}]}
      ]}}}
    ]
  }
}
```

示例只展示参数位置；提交时使用完整目标网络，包含全部应保留的网络、端口实参和实际连线。改 ST 接口时提供完整 `declarations` 列表；省略则保留原表。将其余受影响调用者一起放入 `edits`。`edit_gxw_project` 不接受 `generation_context_id`；单图候选工具接受时才转交该 ID。

参数图可用 `calls` 或具名 `nodes`/`wires`，Core 处理分块与布线。保留 `source_block`、`title`、`block_comment`、图内注释及不可参数化的保留块；需要显式调用顺序时使用 `execution_order`。EN 关闭、IN 为 FALSE 与复位不等价。新增非法 FBD 字面量在 `checked` 和 `draft` 下都拒绝；不把 `INT#0` 自动改写，也不自动将 TIME 取整。其他已知新增源码错误由 `checked` 拒绝；旧工程错误与本次新增诊断分别报告。

查看图形、项目定义和用户库分别调用 `read_fbd_project`、`read_fbd_definition`、`read_fbd_libraries`。导入用户库时使用 `create_fbd_candidate(operation="import_library")`，绑定已保存的目标版本，传入来源 GXW 的 `data_base64` 与实际 `library_name`。当前只转移已覆盖的 ST 实现、接口和库内类型，FBD 库正文转移不受支持；目标源码、任务、调用者及声明保留。需要原生编译并保存时才对已保存版本调用 `operation="compile"`。

`native_save` 是布尔值，显式 `true` 可要求准备阶段原生保存；候选确认后的交付流程仍会在发现 GX Works2 后默认编译、保存及冷重开，`false` 不关闭该默认行为。`create_fb`、`create_program` 和 `import_library` 保留各自的创建或导入流程。根据实际验证字段判断结果，文件保存本身不能证明编译或运行通过。

### ST 程序与块定义

1. 调用 `read_st_project` 读取既有 Program、FB、FUNCTION 的正文、返回类型、声明表和任务归属。
2. 编辑既有对象时，以读取结果中的准确逻辑身份作为 `source_name`，调用 `create_st_candidate` 的 `edit_st_program`、`edit_st_fb`、`edit_st_function` 或通用 `edit_st_source`；多源码联合修改也可使用 `edit_gxw_project`。
3. 只改正文时省略 `declarations`，保留原声明。需要改声明时传入完整目标列表：给出的列表整体替换原表，未列出的旧声明将删除，列表本身决定名称和顺序；`[]` 表示请求清空，仍须通过现有引用及类型检查。整表替换不与 `remove_declarations`、`renames` 或 `order` 混用。
4. 新工程尚无 GXW 版本时，按 `get_generation_context` 返回的 `operation=generate` 合同，通过 `create_st_candidate` 提交 `st_text` 与完整 `declarations`。后台工厂按实际 CPU 创建工程，并绑定读回的 Program 和任务；失败时报告具体阶段与原因。向已有工程新增 Program 时，仍使用读取到的资源和任务构造 `task_binding`。

例如，只修改已读取对象的正文并保留声明：

```json
{"tool":"create_st_candidate","arguments":{"operation":"edit_st_source","source_name":"${实际逻辑源码身份}","st_text":"${完整目标ST正文}"}}
```

上述 `edit_*` 为后台候选编辑；可见批次和 Live 会话继续按 `execute_native_engineering` 自己的操作集合调用。候选确认、保存回读、原生编译与运行结果分别报告。

### 已有 SFC 工程

调用 `read_sfc_project` 读取既有 SFC 的步骤、转换、动作、分支及子程序（需要原生格点坐标时传 `native=true`），再通过 `create_sfc_candidate(operation="edit")` 或 `edit_gxw_project` 在既有 POU 范围内提交修改。

## 7. 无界面后台原生编译检查

确认当前已选中包含 `.gxw` 的保存版本后，调用：

```json
{"tool":"validate_project","arguments":{"native":true}}
```

如需指定目标 POU 上下文可传入 `program`。从返回结果中查看 `compilation`（编译完成与通过状态）、`public_check`、`current_source_check` 及具体诊断列表。

## 后台原生编译与版本交付

对已保存的 Ladder/ST/FBD/SFC GXW，使用当前选中版本调用：

```json
{"plan":{"schema_version":1,"mode":"background","commands":[{"operation":"compile"},{"operation":"save"},{"operation":"reopen"}]}}
```

工具为 `execute_native_engineering`。三个步骤组成后台原生工作区的一次编译保存流程，重开后核对保存代码；请求通过后直接执行，不要求改成 full。成功返回同语言新版本，失败保留原活动版本。源码修改先通过对应候选工具或 `edit_gxw_project` 保存，后台编译不包含可见页面编辑。仅检查时使用 `validate_project(native=true)`。

## 8. 在 GX Works2 中连续可见编辑（Live 会话）

1. **启动会话**：选中目标工程后，调用 `execute_native_engineering` 并传入 `plan.mode="live"`、`session_action="start"`，记录返回的工程会话 `session_id`。首次为该工程创建一份受管 GXW 工作副本，保留原保存版本；后续调用及 MCP 重启继续复用同一路径和原 GX Works2 窗口。重复 `start` 返回已有会话，不执行本次提交的命令列表。
2. **分步推进**：每次继续操作前，先调用 `get_native_engineering_session` 获取当前 `controls.expected_revision` 与待处理状态，再提交 `session_action="continue"`。在持续会话内获取生成上下文时传入 `execution_mode="live"`。
3. **暂停与恢复**：需要暂停时调用 `pause_native_engineering_session(session_id=...)`。MCP 退出仅分离可恢复会话；新 MCP 进程查询状态会加载持久记录，`rebind` / `continue` 在修改前核对原 PID、进程启动时间、HWND、工作路径与 CPU。目标丢失或身份不符时报告需要协调，不新开窗口、复制工程或重放动作；旧记录字段不完整时明确报错。中断或超时后先 `rebind` 只读观察实际状态；恢复已有待处理队列使用空命令列表及 `controls.resume_pending=true`。
4. **会话内编译与地址查询**：在当前修订上执行 `compile` 步骤后，可通过 `show_assignments` 查询编译器分配地址；后续继续修改源码会使此前的编译与地址结果变为 `stale`。
5. **保存与结束**：按任务阶段显式编译、保存或冷重开。保存验收忽略 Live 时间戳内容，仍检查实际正文、声明等实质内容；按工具实际结果区分保存、编译和运行。显式 `session_action="end"` 才结束会话，GX 窗口保持打开。

## 9. 查询编译器分配地址、代码一致性与步号定位

基于当前已保存的 `.gxw` 版本，传入工程内实际的声明表名、POU 名或资源名：

```json
{"tool":"read_native_device_assignments","arguments":{"queries":[{"source":"${实际全局声明表}","name":"${实际变量名}","scope":"global"}]}}
```

```json
{"tool":"compare_native_compiled_code","arguments":{}}
```

```json
{"tool":"locate_native_code_steps","arguments":{"queries":[{"resource":"${实际资源名}","step":12}]}}
```

## 10. 读取 Simulator2 软元件与波形时间轴

1. **获取目标**：调用 `list_simulator_targets` 查看已连接目标；若尚未连接且任务需要连接本机 Simulator2，调用 `connect_simulator` 获取 `target_ref`。
2. **读取状态或软元件值**：

```json
{"tool":"read_simulator_devices","arguments":{"target_ref":"${target_ref}","addresses":["Y0"]}}
```

3. **启动波形采样**：

```json
{
  "tool":"start_simulator_trace",
  "arguments":{
    "target_ref":"${target_ref}",
    "config":{
      "signals":[{"id":"output_y0","label":"Y0","address":"Y0","data_type":"BOOL"}],
      "sample_ms":100,
      "duration_ms":10000
    }
  }
}
```

采样期间或结束后可通过 `get_simulator_trace(view_ref)` 查看采样进度、波形数据与时间轴页面地址，需要提前结束采样时调用 `stop_simulator_trace(view_ref)`。


所有上述 `search_plc_manual`、`get_generation_context`、`get_fbd_catalog` 步骤均先完成 `delivery.next` 续读并合并 `objects`；本文字段路径均针对解析后的 `document`。工程版本或事实库更新后重新获取上下文，不复用旧游标。
